import processing.core.PImage;

import java.util.List;

public class CSB extends Entity{
    public CSB(String id, Point position, List<PImage> images, int health) {
        super(id, position, images, health);
    }
}
